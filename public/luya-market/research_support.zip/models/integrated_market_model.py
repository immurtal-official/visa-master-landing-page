#!/usr/bin/env python3
"""Consolidated unverified Luya analyst scenarios. Standard library only; no legacy mutation."""
import argparse,copy,csv,json,math,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
INPUT=ROOT/'evidence/integrated-scenario-assumptions.json'
OUT=ROOT/'models/integrated-outputs'

def load():return json.loads(INPUT.read_text())
def events(a,s):
    v=lambda k:a['source_anchors'][k]['value']
    dom=v('INT-WTTC-DOM2025')/s['global_domestic_spend_per_trip_usd']
    intl=v('OBS-P3C-UN-ARRIVALS')/s['arrival_per_international_chain']
    global_events=dom+intl-min(dom,intl)*s['domestic_international_overlap']
    cn=v('OBS-CN25-DOMTRIPS')+v('OBS-CN25-OUT')*(1-s['domestic_international_overlap'])
    tw=(v('OBS-TW25-DOM-PRECISE')+v('OBS-TW25-OUT-ALLAGES')*(1-s['domestic_international_overlap']))*s['tw_resident_adult_bridge']
    hk=v('OBS-HK25-DEPART')*s['hk_leisure_departure_fraction']+a['geographies']['HK']['population_guardrail']*s['hk_mo_staycation_trips_per_person']
    mo=v('OBS-MO25-OUT-TOTAL')*s['mo_leisure_departure_fraction']+a['geographies']['MO']['population_guardrail']*s['hk_mo_staycation_trips_per_person']
    gc=cn+tw+hk+mo
    if gc>global_events:raise ValueError('GC exceeds global event equivalent spine')
    return {'CN':cn,'TW':tw,'HK':hk,'MO':mo,'ROW':global_events-gc}, {'global_domestic_trip_equivalents':dom,'global_international_trip_chains':intl,'global_overlap_haircut':min(dom,intl)*s['domestic_international_overlap'],'global_origin_trip_equivalents':global_events,'gc_origin_trip_equivalents':gc,'row_origin_trip_equivalents':global_events-gc}

def revenue(a,s,geo,active,extension_scale=1,pay_factor=1,price_factor=1):
    g=a['geographies'][geo];fx=a['fx'][g['currency']]['usd_per_local'];freq=s['trip_frequency']*g['trip_frequency_multiplier'];trips=active*freq
    subshare=min(s['subscriber_share']*pay_factor,1);pay=min(s['per_trip_payment']*pay_factor,1)
    sub=active*subshare;unsub=active-sub
    subscriber_trips=sub*s['subscriber_trip_frequency']*g['trip_frequency_multiplier']
    # All-subscriber boundary uses total trips; default small subscriber shares have positive residual.
    subscriber_trips=min(subscriber_trips,trips)
    nonsubscriber_trips=trips-subscriber_trips
    non_sub_frequency=nonsubscriber_trips/unsub if unsub else 0
    paid_trips=nonsubscriber_trips*pay
    quote_factor=s['price_factor']*price_factor
    gross_sub=sub*g['annual_price']*fx*quote_factor
    gross_trip=paid_trips*g['trip_price']*fx*quote_factor
    core=(gross_sub+gross_trip)*(1-s['refund'])
    annual_payers=sub+unsub*(1-(1-pay)**non_sub_frequency)
    gmv=trips*s['booking_attach']*g['booking_gmv_per_attached_trip_usd']*s['booking_settled_fraction']*extension_scale
    booking=gmv*s['booking_net_take']
    visa_tasks=trips*g['visa_need_per_trip']*s['visa_buy_fraction']*extension_scale
    visa=visa_tasks*g['visa_price']*fx*quote_factor*(1-s['refund'])
    return {'active_accounts':active,'served_party_trips':trips,'core_free_party_trips':nonsubscriber_trips-paid_trips,'core_entitled_party_trips':subscriber_trips+paid_trips,'subscriber_party_trips':subscriber_trips,'non_subscriber_party_trips':nonsubscriber_trips,'subscription_accounts':sub,'non_subscriber_accounts':unsub,'per_trip_paid_baskets':paid_trips,'core_paying_account_equivalents':annual_payers,'gross_charged_core_payer_equivalents':annual_payers,'net_retained_core_payer_equivalents':annual_payers*(1-s['refund']),'subscription_revenue_usd':gross_sub*(1-s['refund']),'per_trip_revenue_usd':gross_trip*(1-s['refund']),'core_digital_revenue_usd':core,'booking_gmv_usd':gmv,'booking_net_revenue_usd':booking,'visa_paid_tasks':visa_tasks,'visa_net_revenue_usd':visa,'integrated_revenue_usd':core+booking+visa,'gross_core_billings_usd':gross_sub+gross_trip,'core_arpu_usd':core/active if active else 0,'integrated_arpu_usd':(core+booking+visa)/active if active else 0}

SUMKEYS=['origin_trip_equivalents','joint_eligible_person_trip_equivalents','eligible_payer_party_trips','annual_equivalent_accounts','category_active_accounts','near_active_accounts','expanded_active_accounts','core_tam_usd','booking_extension_tam_usd','visa_extension_tam_usd','integrated_tam_usd','core_near_sam_usd','integrated_near_sam_usd','core_expanded_sam_usd','integrated_expanded_sam_usd']
def markets(a,sc):
    s=a['scenarios'][sc];ev,bridge=events(a,s);rows=[]
    for geo,g in a['geographies'].items():
        joint=s[geo.lower()+'_joint_eligible'];eligible=ev[geo]*joint;party=eligible/s['party_size'];accts=party/(s['trip_frequency']*g['trip_frequency_multiplier'])
        if accts>g['population_guardrail']:raise ValueError('Equivalent account population plausibility exceeded')
        active=accts*s['category_adoption'];near=min(g['near_coverage']*s['near_coverage_scale'],1);expanded=min(g['expanded_coverage']*s['expanded_coverage_scale'],1)
        if near>expanded:raise ValueError('near exceeds expanded coverage')
        rev=revenue(a,s,geo,active)
        rows.append({'scenario':sc,'geography':geo,'currency':g['currency'],'origin_trip_equivalents':ev[geo],'joint_eligible_person_trip_equivalents':eligible,'eligible_payer_party_trips':party,'annual_equivalent_accounts':accts,'category_active_accounts':active,'near_coverage':near,'expanded_coverage':expanded,'near_active_accounts':active*near,'expanded_active_accounts':active*expanded,'core_tam_usd':rev['core_digital_revenue_usd'],'booking_extension_tam_usd':rev['booking_net_revenue_usd'],'visa_extension_tam_usd':rev['visa_net_revenue_usd'],'integrated_tam_usd':rev['integrated_revenue_usd'],'core_near_sam_usd':rev['core_digital_revenue_usd']*near,'integrated_near_sam_usd':rev['integrated_revenue_usd']*near,'core_expanded_sam_usd':rev['core_digital_revenue_usd']*expanded,'integrated_expanded_sam_usd':rev['integrated_revenue_usd']*expanded,'annual_quote_local':g['annual_price']*s['price_factor'],'trip_quote_local':g['trip_price']*s['price_factor'],'annual_quote_usd':g['annual_price']*s['price_factor']*a['fx'][g['currency']]['usd_per_local'],'trip_quote_usd':g['trip_price']*s['price_factor']*a['fx'][g['currency']]['usd_per_local'],'confidence':'low; unverified analyst scenario'})
    for agg,geos in [('Greater_China',['CN','HK','MO','TW']),('Global',['CN','HK','MO','TW','ROW'])]:
        members=[r for r in rows if r['geography'] in geos];row={'scenario':sc,'geography':agg,'currency':'USD','confidence':'low; unverified analyst scenario'}
        row.update({k:sum(r[k] for r in members) for k in SUMKEYS});rows.append(row)
    return rows,bridge

def forecast(a,sc,market_rows,cac_factor=1,retention_override=None,pay_factor=1,price_factor=1):
    s=a['scenarios'][sc];p=a['company_plan'];rows=[];channels=[];prev={g:0 for g in a['geographies']};ms={r['geography']:r for r in market_rows};ret=s['retention'] if retention_override is None else retention_override
    for y in range(5):
        for geo,g in a['geographies'].items():
            m=ms[geo];budget=p['annual_acquisition_budget_usd'][y]*s['budget_factor']*g['channel_budget_share'];paid_new_raw=0
            for name,share,costmult in [('paid_search',.35,1.2),('paid_social',.45,1),('creator_partnership',.20,.8)]:
                cpa=g['cost_per_new_activated_usd']*s['acquisition_cost_factor']*cac_factor*costmult;spend=budget*share;raw=spend/cpa
                paid_new_raw+=raw;channels.append({'scenario':sc,'geography':geo,'year':y+1,'calendar_year':2027+y,'channel':name,'budget_usd':spend,'cost_per_new_activated_account_usd':cpa,'gross_activated_new':raw,'dedup_haircut':.10,'dedup_activated_new':raw*.9,'status':'proposed budget and CPA; zero verified commitments'})
            paid_new=paid_new_raw*.9;organic=p['annual_unique_organic_new_accounts'][y]*s['organic_factor']*g['organic_share']
            covfraction=p['near_to_expanded_coverage_fraction'][y];sam_cap=(m['near_active_accounts']+(m['expanded_active_accounts']-m['near_active_accounts'])*covfraction)*(1+s['trip_growth'])**(y+1)
            capacity=p['annual_active_account_capacity'][y]*s['capacity_factor']*g['capacity_share'];cap=min(sam_cap,capacity)
            retained=min(prev[geo]*ret,cap);new=min(paid_new+organic,max(cap-retained,0));active=retained+new;prev[geo]=active
            realized_paid_new=new*paid_new/(paid_new+organic) if paid_new+organic else 0
            realized_organic_new=new-realized_paid_new
            rev=revenue(a,s,geo,active,p['booking_visa_rollout'][y],pay_factor,price_factor)
            ai=rev['served_party_trips']*s['cost_per_trip'];support=rev['core_paying_account_equivalents']*s['cost_per_payer'];credits=active*s['credits_cost_per_active'];bookingcost=rev['booking_net_revenue_usd']*s['booking_servicing_fraction'];visacost=rev['visa_net_revenue_usd']*s['visa_servicing_fraction'];fixedplatform=p['annual_platform_fixed_usd'][y]*s['staff_budget_factor']*g['capacity_share']
            cogs=ai+support+credits+bookingcost+visacost+fixedplatform;gp=rev['integrated_revenue_usd']-cogs;channel=(rev['gross_core_billings_usd']+rev['visa_net_revenue_usd']/(1-s['refund']))*s['channel_fee'];contrib=gp-channel-budget;fixed=p['annual_fixed_people_content_admin_usd'][y]*s['staff_budget_factor']*g['capacity_share'];op=contrib-fixed;capex=p['annual_development_capex_usd'][y]*s['staff_budget_factor']*g['capacity_share']
            payerprob=rev['net_retained_core_payer_equivalents']/active if active else 0;ltv=(gp-channel)/active/(1-ret) if active else 0
            row={'scenario':sc,'geography':geo,'year':y+1,'calendar_year':2027+y,**rev,'paid_new_activated_accounts_before_capacity':paid_new,'organic_unique_new_before_capacity':organic,'new_activated_accounts':new,'realized_paid_new_accounts':realized_paid_new,'realized_organic_new_accounts':realized_organic_new,'retained_active_accounts':retained,'active_sam_cap':sam_cap,'active_delivery_cap':capacity,'capacity_bound':active>=cap-1e-6,'acquisition_budget_usd':budget,'full_stack_usage_cogs_usd':ai,'free_usage_cogs_usd':rev['core_free_party_trips']*s['cost_per_trip'],'paid_entitlement_usage_cogs_usd':rev['core_entitled_party_trips']*s['cost_per_trip'],'payer_support_cogs_usd':support,'credits_redemption_cogs_usd':credits,'booking_service_cogs_usd':bookingcost,'visa_service_cogs_usd':visacost,'fixed_platform_cogs_usd':fixedplatform,'total_cogs_usd':cogs,'gross_profit_usd':gp,'gross_margin':gp/rev['integrated_revenue_usd'] if rev['integrated_revenue_usd'] else 0,'payment_channel_cost_usd':channel,'contribution_profit_usd':contrib,'contribution_margin':contrib/rev['integrated_revenue_usd'] if rev['integrated_revenue_usd'] else 0,'fixed_people_content_admin_usd':fixed,'operating_profit_usd':op,'development_capex_usd':capex,'operating_cash_proxy_usd':op-capex,'core_cac_per_new_payer_usd':budget/(realized_paid_new*payerprob) if realized_paid_new*payerprob else 0,'steady_state_variable_contribution_ltv_usd':ltv,'profit_status':'ex-tax simplified budget scenario; not recognized accounting profit'};rows.append(row)
        for agg,geos in [('Greater_China',['CN','HK','MO','TW']),('Global',['CN','HK','MO','TW','ROW'])]:
            members=[r for r in rows if r['year']==y+1 and r['geography'] in geos];r={'scenario':sc,'geography':agg,'year':y+1,'calendar_year':2027+y,'profit_status':'ex-tax simplified budget scenario'}
            numeric=[k for k,v in members[0].items() if isinstance(v,(int,float)) and not isinstance(v,bool) and k not in ['year','calendar_year','gross_margin','contribution_margin','core_arpu_usd','integrated_arpu_usd','core_cac_per_new_payer_usd','steady_state_variable_contribution_ltv_usd']]
            r.update({k:sum(m[k] for m in members) for k in numeric});r['gross_margin']=r['gross_profit_usd']/r['integrated_revenue_usd'] if r['integrated_revenue_usd'] else 0;r['contribution_margin']=r['contribution_profit_usd']/r['integrated_revenue_usd'] if r['integrated_revenue_usd'] else 0;r['core_arpu_usd']=r['core_digital_revenue_usd']/r['active_accounts'] if r['active_accounts'] else 0;r['integrated_arpu_usd']=r['integrated_revenue_usd']/r['active_accounts'] if r['active_accounts'] else 0
            paidnew=sum(m['realized_paid_new_accounts']*(m['net_retained_core_payer_equivalents']/m['active_accounts'] if m['active_accounts'] else 0) for m in members);r['core_cac_per_new_payer_usd']=r['acquisition_budget_usd']/paidnew if paidnew else 0;r['steady_state_variable_contribution_ltv_usd']=(r['gross_profit_usd']-r['payment_channel_cost_usd'])/r['active_accounts']/(1-ret) if r['active_accounts'] else 0;rows.append(r)
    # Actual cash needs include initial negative periods; no financing assumption or minimum cash provided.
    for geo in ['CN','HK','MO','TW','ROW','Greater_China','Global']:
        cum=0;need=0
        for r in [r for r in rows if r['geography']==geo]:cum+=r['operating_cash_proxy_usd'];need=max(need,-cum);r['cumulative_operating_cash_proxy_usd']=cum;r['minimum_cumulative_funding_need_usd']=need
    return rows,channels

def output_csv(path,rows):
    keys=[]
    for r in rows:
        for k in r:
            if k not in keys:keys.append(k)
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def build(a):
    market=[];fc=[];channels=[];bridges=[];headline=[];module=[];targets=[];tri=[]
    for sc in a['scenarios']:
        mr,br=markets(a,sc);market+=mr;bridges.append({'scenario':sc,**br});fr,ch=forecast(a,sc,mr);fc+=fr;channels+=ch
        for m in mr:
            geo=m['geography'];f3=next(r for r in fr if r['geography']==geo and r['year']==3);f5=next(r for r in fr if r['geography']==geo and r['year']==5)
            headline.append({'scenario':sc,'geography':geo,'core_tam_usd':m['core_tam_usd'],'booking_extension_tam_usd':m['booking_extension_tam_usd'],'visa_extension_tam_usd':m['visa_extension_tam_usd'],'integrated_tam_usd':m['integrated_tam_usd'],'core_near_sam_usd':m['core_near_sam_usd'],'integrated_near_sam_usd':m['integrated_near_sam_usd'],'core_expanded_sam_usd':m['core_expanded_sam_usd'],'integrated_expanded_sam_usd':m['integrated_expanded_sam_usd'],'core_y3_som_usd':f3['core_digital_revenue_usd'],'integrated_y3_som_usd':f3['integrated_revenue_usd'],'core_y5_som_usd':f5['core_digital_revenue_usd'],'integrated_y5_som_usd':f5['integrated_revenue_usd'],'y5_operating_profit_usd':f5['operating_profit_usd'],'y5_active_accounts':f5['active_accounts'],'y5_gmv_usd':f5['booking_gmv_usd'],'confidence':'low; all estimates conditional'})
            for name,weight in a['modules'].items():module.append({'scenario':sc,'geography':geo,'module':name,'allocation_weight_of_core':weight,'allocated_core_tam_usd':m['core_tam_usd']*weight,'incremental_extension_tam_usd':0,'basis':'analytic allocation of same exclusive bundle/payment; no standalone category TAM addition'})
            for name,k in [('Booking_Commissions','booking_extension_tam_usd'),('Visa_Preparation','visa_extension_tam_usd')]:module.append({'scenario':sc,'geography':geo,'module':name,'allocation_weight_of_core':0,'allocated_core_tam_usd':0,'incremental_extension_tam_usd':m[k],'basis':'distinct service rights; hypothetical future contract/delivery eligibility'})
            if geo in ['Global','Greater_China']:
                unit=f5['integrated_arpu_usd'];core=f5['core_arpu_usd'];target=100000000
                targets.append({'scenario':sc,'geography':geo,'target_annual_revenue_usd':target,'integrated_revenue_per_active_usd':unit,'required_active_accounts_integrated':target/unit if unit else None,'required_active_accounts_digital_only':target/core if core else None,'required_served_party_trips_integrated':target/f5['integrated_revenue_usd']*f5['served_party_trips'] if unit else None,'required_booking_gmv_at_same_mix_usd':target/f5['integrated_revenue_usd']*f5['booking_gmv_usd'],'required_active_as_fraction_expanded_sam':target/unit/m['expanded_active_accounts'] if unit else None,'scale_vs_y5_integrated_som':target/f5['integrated_revenue_usd'],'interpretation':'algebra at same mix; not feasible acquisition, supported capacity or validated demand'})
        gl=next(r for r in mr if r['geography']=='Global');cn=next(r for r in mr if r['geography']=='CN');tw=next(r for r in mr if r['geography']=='TW')
        for company,rev_id,gb_id in [('Booking','OBS-P4A-BK-REV','OBS-P4A-BK-GB'),('Airbnb','OBS-P4A-AB-REV','OBS-P4A-AB-GB')]:
            tri.append({'scenario':sc,'test':'comparable_'+company+'_group_revenue_to_gross_booking_ratio','value':a['source_anchors'][rev_id]['value']/a['source_anchors'][gb_id]['value'],'unit':'group_revenue/gross_booking_value','interpretation':'Corporate portfolio ratio using rounded2025source facts, not net affiliate commission; not applied to Luya. Shared-price calibration is not independent market validation.'})
        spend=a['source_anchors']['INT-WTTC-DOM2025']['value'];tri.extend([{'scenario':sc,'test':'top_down_budget_global_core_vs_domestic_spend','value':gl['core_tam_usd']/spend,'unit':'fraction','interpretation':'budget intensity check, shared inputs; international numerator included while denominator domestic only, conservative context ratio not independent estimate'},{'scenario':sc,'test':'top_down_budget_cn_core_vs_domestic_spend','value':cn['core_tam_usd']/(a['source_anchors']['OBS-CN25-DOMSPEND']['value']*a['fx']['CNY']['usd_per_local']),'unit':'fraction','interpretation':'budget sanity check; CN numerator domestic+outbound, denominator domestic only; not independent validation'},{'scenario':sc,'test':'top_down_budget_tw_core_vs_domestic_spend','value':tw['core_tam_usd']/a['source_anchors']['OBS-TW25-DOM-USD-REPORTED']['value'],'unit':'fraction','interpretation':'budget sanity check; TW numerator domestic+outbound; source-reported nominal2025USD spending, not2026FX'},{'scenario':sc,'test':'comparable_booking_hypothetical_net_take','value':a['scenarios'][sc]['booking_net_take'],'unit':'net_revenue/settled_gmv','interpretation':'assumed startup affiliate economics. OTA corporate take rates are different business model and not Luya contract evidence'}])
    sensitivity=[]
    base_market,_=markets(a,'base')
    for pay in [.5,1,1.5]:
        for price in [.7,1,1.3]:
            fr,_=forecast(a,'base',base_market,pay_factor=pay,price_factor=price)
            for r in fr:
                if r['year']==5 and r['geography'] in ['Global','Greater_China']:sensitivity.append({'grid':'pay_x_price','geography':r['geography'],'pay_factor':pay,'price_factor':price,'cac_factor':1,'retention':a['scenarios']['base']['retention'],'y5_revenue_usd':r['integrated_revenue_usd'],'y5_operating_profit_usd':r['operating_profit_usd'],'y5_active_accounts':r['active_accounts']})
    for cac in [.7,1,1.5]:
        for retention in [.25,.42,.60]:
            fr,_=forecast(a,'base',base_market,cac_factor=cac,retention_override=retention)
            for r in fr:
                if r['year']==5 and r['geography'] in ['Global','Greater_China']:sensitivity.append({'grid':'cac_x_retention','geography':r['geography'],'pay_factor':1,'price_factor':1,'cac_factor':cac,'retention':retention,'y5_revenue_usd':r['integrated_revenue_usd'],'y5_operating_profit_usd':r['operating_profit_usd'],'y5_active_accounts':r['active_accounts']})
    return {'headline':headline,'geographic_market':market,'forecast':fc,'channels':channels,'event_bridge':bridges,'module_bridge':module,'target_100m':targets,'triangulation':tri,'sensitivity':sensitivity}

def assumption_rows(a):
    rows=[]
    def add(scope,key,v,unit='',reason='Unverified analyst planning assumption; not Luya operating evidence.'):
        rows.append({'assumption_id':'INT-'+scope+'-'+key,'scope':scope,'parameter':key,'value':json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v,'unit':unit,'evidence_tier':'analyst_assumption','status':'unverified_scenario','as_of':a['as_of'],'rationale_limitations':reason})
    explanations={'global_domestic_spend_per_trip_usd':'USD500/350/250 proxy calibrated to US2025~493.75, EU2025~313.92EUR, CN2025~965.96CNY and TW2025~2278.95TWD per trip. Different trip/spend definitions; no global weighted trip average measured. Higher cost proxy gives lower conservative count.','domestic_international_overlap':'Haircut only the smaller outbound/international chain series to remove potentially embedded domestic legs; not overlap of distinct persons across different trips. No overlap statistic exists.','category_adoption':'Share of eligible account-equivalents using paid-category service including free users; independent analyst20/40/60%, not AI survey intention.','hk_leisure_departure_fraction':'15/25/40% of border departures modeled as distinct leisure journey events. Not official tourism purpose statistic; excludes commuting/day-to-day crossings by assumption.','mo_leisure_departure_fraction':'4/7/10% of border departures modeled as leisure journeys. Particularly uncertain due repeated mainland boundary crossings.','subscriber_share':'1.5/4/8% of active annual account-equivalents pay subscription. Remaining accounts can only pay exclusive trip basket. Not observed conversion.','per_trip_payment':'4/10/18% of non-subscriber served trips purchase a basket. Coupled with price scenarios without assigned probability or estimated elasticity.','cost_per_trip':'USD0.32/0.20/0.13 per all active free+paid party trip: budget for text, vision/audio, maps/search, storage and retries; no vendor-measured workload.','cost_per_payer':'USD1.25/0.85/0.60 per annual core paying-account equivalent for human support/moderation. No observed load; local content fixed team also in staff budget.','credits_cost_per_active':'Expected cash fulfillment/moderation budget per free+paid active account, no Credits face value counted as sales.','booking_net_take':'1.5/2.5/4% net affiliate rate on settled GMV, entirely hypothetical future commercial agreement; not OTA corporate take.','channel_fee':'18/15/12% blended single payment distribution path on gross digital+visa billings; no added second payment processor fee.','retention':'22/42/62% of preceding annual active cohort returns next year; churn absorbed, no resurrection; no observed Luya cohort.'}
    for sc,vals in a['scenarios'].items():
        for k,v in vals.items():add(sc,k,v,reason=explanations.get(k,'Unverified analyst scenario parameter; bounds reflect execution range, not statistical confidence interval.'))
    for geo,vals in a['geographies'].items():
        for k,v in vals.items():add(geo,k,v,reason=vals['price_analogue'] if 'price' in k else 'Geographic analyst planning input; population_guardrail is a rounded plausibility assumption, not a census statistic.')
    for k,v in a['company_plan'].items():add('company',k,v,reason='Proposed 2027E-2031E operating budget or rollout path; no authorized spend, customer pipeline or signed contracts evidenced.')
    for k,v in a['modules'].items():add('module',k,v,reason='Mutually exclusive allocation of same core cash basket for analysis; not independent module willingness to pay.')
    for k,v in a['policy'].items():add('policy',k,v)
    add('channels','paid_search_paid_social_creator_share',[.35,.45,.20],reason='Proposed channel budget split; no observed channel performance.')
    add('channels','search_social_creator_cpa_multiplier',[1.2,1,.8],reason='Proposed relative activation cost; actual cost unknown.')
    add('channels','paid_activation_cross_channel_dedup',.10,reason='10% haircut on gross paid activations; organic new forecast already assumed net of paid/prior-user overlaps. Unknown true overlap.')
    return rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true');args=ap.parse_args();a=load();outputs=build(a);summary={'schema_version':a['schema_version'],'as_of':a['as_of'],'classification':a['classification'],'confidence':a['confidence'],'money_basis':a['money_basis'],'forecast_year_map':{str(y):2026+y for y in range(1,6)},'headline':outputs['headline'],'aggregate_forecast':[r for r in outputs['forecast'] if r['geography'] in ['Global','Greater_China']],'source_anchors':a['source_anchors'],'calibration_source_file':a['calibration_source_file'],'limitations':a['policy']}
    if args.check:
        old=json.loads((OUT/'summary.json').read_text());assert old==summary,'Stored model output drift';print('Integrated model regeneration PASS');return
    OUT.mkdir(exist_ok=True)
    for name,rows in outputs.items():output_csv(OUT/(name+'.csv'),rows)
    output_csv(ROOT/'evidence/integrated-scenario-assumptions.csv',assumption_rows(a));(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps({'rows':{k:len(v) for k,v in outputs.items()},'headline': [r for r in outputs['headline'] if r['geography'] in ['Global','Greater_China']]},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
