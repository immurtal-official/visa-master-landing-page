# -*- coding: utf-8 -*-
"""Original A4 institutional research layout; editable Word tables and styles."""
from pathlib import Path
from docx import Document
from docx.shared import Mm,Pt,RGBColor,Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE

ROOT=Path(__file__).resolve().parents[2]
NAVY='18384B';TEAL='276D72';GRAY='5C6670';PALE='EBF0F2';INK='20262C'

def fontstyle(style,size=10.5,bold=False,color=INK,east='Songti SC'):
 style.font.name='Arial';style.font.size=Pt(size);style.font.bold=bold;style.font.color.rgb=RGBColor.from_string(color)
 rf=style.element.get_or_add_rPr().get_or_add_rFonts();rf.set(qn('w:eastAsia'),east);rf.set(qn('w:ascii'),'Arial');rf.set(qn('w:hAnsi'),'Arial')
 for key in ['asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme']:
  rf.attrib.pop(qn('w:'+key),None)
 lang=OxmlElement('w:lang');lang.set(qn('w:val'),'en-US');lang.set(qn('w:eastAsia'),'zh-CN');style.element.get_or_add_rPr().append(lang)

def no_split(row):
 p=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(p)

def cellshade(cell,fill):
 s=OxmlElement('w:shd');s.set(qn('w:fill'),fill);cell._tc.get_or_add_tcPr().append(s)

def hyperlink(paragraph,text,url,color=GRAY,size=8.5):
 from docx.opc.constants import RELATIONSHIP_TYPE as RT
 rid=paragraph.part.relate_to(url,RT.HYPERLINK,is_external=True)
 h=OxmlElement('w:hyperlink');h.set(qn('r:id'),rid)
 r=OxmlElement('w:r');pr=OxmlElement('w:rPr');c=OxmlElement('w:color');c.set(qn('w:val'),color);pr.append(c)
 fs=OxmlElement('w:sz');fs.set(qn('w:val'),str(int(size*2)));pr.append(fs);r.append(pr);t=OxmlElement('w:t');t.text=text;r.append(t);h.append(r);paragraph._p.append(h)

class Report:
 def __init__(self):
  self.doc=Document();sec=self.doc.sections[0];sec.page_width=Mm(210);sec.page_height=Mm(297)
  sec.top_margin=Mm(18);sec.bottom_margin=Mm(17);sec.left_margin=Mm(19);sec.right_margin=Mm(19);sec.header_distance=Mm(8);sec.footer_distance=Mm(8)
  sty=self.doc.styles
  # Strip inherited decorative rules from the stock Word template.
  for style in sty:
   for border in list(style.element.iter(qn('w:pBdr'))):
    border.getparent().remove(border)
  fontstyle(sty['Normal'],10.5);sty['Normal'].paragraph_format.line_spacing=1.29;sty['Normal'].paragraph_format.space_after=Pt(6)
  for n,size in [('Title',24),('Heading 1',16),('Heading 2',11.7),('Heading 3',10.5)]:
   fontstyle(sty[n],size,True,'000000','Hiragino Sans GB');sty[n].paragraph_format.space_before=Pt(8);sty[n].paragraph_format.space_after=Pt(8);sty[n].paragraph_format.keep_with_next=True
  for n,size in [('Source Note',8.5),('Exhibit Title',10),('Small Text',9),('Table Text',9),('Table Head',9)]:
   if n not in sty:sty.add_style(n,WD_STYLE_TYPE.PARAGRAPH)
   fontstyle(sty[n],size,n in ['Exhibit Title','Table Head'],GRAY if n=='Source Note' else INK,'Hiragino Sans GB' if n in ['Exhibit Title','Table Head'] else 'Songti SC')
   sty[n].paragraph_format.line_spacing=1.13;sty[n].paragraph_format.space_after=Pt(4)
  sty['Exhibit Title'].paragraph_format.keep_with_next=True
  for n in ['Source Note','Small Text','Table Text','Table Head']:sty[n].paragraph_format.widow_control=True
  p=sec.header.paragraphs[0];p.text='LUYA   旅行科技与投资研究';p.style='Source Note'
  p=sec.footer.paragraphs[0];p.style='Source Note';p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
  p.add_run('2026年10月30日     |     ')
  field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');p._p.append(field)
  self.markdown=[];self.pages=[]
 def page(self,title,kicker=None,first=False):
  newpage=bool(self.pages)
  self.pages.append(title)
  if kicker:
   p=self.doc.add_paragraph(kicker,'Source Note');p.paragraph_format.space_after=Pt(5);p.paragraph_format.page_break_before=newpage
  p=self.doc.add_paragraph(title,'Title' if first else 'Heading 1');p.paragraph_format.page_break_before=newpage and not kicker
  self.markdown += ['\n\n<!-- page -->\n',('# ' if first else '## ')+title,'']
 def para(self,text,style=None):
  p=self.doc.add_paragraph(text,style);self.markdown.extend([text,'']);return p
 def h2(self,text):self.doc.add_paragraph(text,'Heading 2');self.markdown.extend(['### '+text,''])
 def table(self,title,headers,rows,widths=None,notes=None):
  self.doc.add_paragraph(title,'Exhibit Title');self.markdown.extend(['**'+title+'**','','| '+' | '.join(headers)+' |','|'+'---|'*len(headers)])
  t=self.doc.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
  avail=172; widths=widths or [avail/len(headers)]*len(headers)
  for col,w in zip(t.columns,widths):col.width=Mm(w)
  for i,text in enumerate(headers):
   cell=t.rows[0].cells[i];cell.width=Mm(widths[i]);cellshade(cell,PALE);p=cell.paragraphs[0];p.style='Table Head';p.add_run(str(text));cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
  repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
  for vals in rows:
   row=t.add_row();no_split(row)
   for i,val in enumerate(vals):
    cell=row.cells[i];cell.width=Mm(widths[i]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    p=cell.paragraphs[0];p.style='Table Text';p.paragraph_format.space_after=Pt(4);p.paragraph_format.space_before=Pt(4)
    p.add_run(str(val));
    if str(vals[0]) in ['整合年收入','整合TAM','合并平台收入','经营预算盈余／亏损','大中华区']:
     for run in p.runs:run.font.bold=True
    import re
    if i>0 and (isinstance(val,(int,float)) or re.fullmatch(r'[-+\d.,%×]+',str(val))):p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
   self.markdown.append('| '+' | '.join(str(x).replace('|','/') for x in vals)+' |')
  for row in t.rows:
   for cell in row.cells:
    tc=cell._tc.get_or_add_tcPr();mar=OxmlElement('w:tcMar')
    for key,v in [('top',50),('left',70),('bottom',50),('right',70)]:
     el=OxmlElement('w:'+key);el.set(qn('w:w'),str(v));el.set(qn('w:type'),'dxa');mar.append(el)
    tc.append(mar)
  borders=OxmlElement('w:tblBorders')
  for edge in ['top','bottom','insideH']:
   el=OxmlElement('w:'+edge);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D7DFE2');borders.append(el)
  t._tbl.tblPr.append(borders)
  gap=self.doc.add_paragraph();gap.paragraph_format.space_after=Pt(0);gap.paragraph_format.space_before=Pt(0);gap.paragraph_format.line_spacing=Pt(1)
  gap.add_run().font.size=Pt(1)
  if notes:self.note(notes)
  self.markdown.append('');return t
 def note(self,text,links=None):
  p=self.doc.add_paragraph(text,'Source Note');self.markdown.extend([text,''])
  if links:
   for label,url in links:hyperlink(p,'  '+label,url);self.markdown.append('['+label+']('+url+')')
  return p
 def chart(self,title,path,height_mm=None,notes=None):
  self.doc.add_paragraph(title,'Exhibit Title');p=self.doc.add_paragraph();p.paragraph_format.space_after=Pt(2)
  p.add_run().add_picture(str(path),width=Mm(172))
  self.markdown.extend(['**'+title+'**','',f'![{title}](support/figures/{Path(path).name})',''])
  if notes:self.note(notes)
 def save(self,path):self.doc.save(str(path))
