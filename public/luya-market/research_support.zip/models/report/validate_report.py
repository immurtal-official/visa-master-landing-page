#!/usr/bin/env python3
"""Read-only report/output consistency checks; visual QA is recorded separately."""
from pathlib import Path
import sys,json,csv,re,hashlib,unicodedata,math
from docx import Document
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'models'))
import integrated_market_model as model
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(t):return re.sub(r'\s+','',unicodedata.normalize('NFKC',t))
def main():
 out=ROOT/'deliverables';doc=Document(out/'investment_report.docx');md=(out/'investment_report.md').read_text();pdf=PdfReader(out/'investment_report.pdf');pt='\n'.join(p.extract_text() for p in pdf.pages);nt=norm(pt)
 content=json.loads((ROOT/'research/production/content-map.json').read_text())
 assert len(pdf.pages)==content['intended_pages']==27
 assert all(tuple(round(float(v),1) for v in p.mediabox[2:])==(595.3,841.9) for p in pdf.pages)
 captions=[p.text for p in doc.paragraphs if p.text.startswith('Exhibit ')]
 assert [int(re.match(r'Exhibit (\d+)',t).group(1)) for t in captions]==list(range(1,34))
 assert len(doc.tables)==29 and len(doc.inline_shapes)==4
 assert all(norm(t) in nt for t in captions), 'Missing PDF exhibit title'
 assert '\ufffd' not in pt and '待模型' not in pt
 cells=[c.text for t in doc.tables for r in t.rows for c in r.cells]
 missing=[v for v in cells if norm(v) not in nt]
 assert not missing, 'DOCX table content missing in PDF: '+str(missing[:6])
 assert all(v.replace('|','/') in md for v in cells), 'DOCX table missing in Markdown'
 links={v.target_ref for v in doc.part.rels.values() if v.reltype.endswith('/hyperlink')}
 sources=list(csv.DictReader((out/'support/report-sources.csv').open(encoding='utf-8-sig')))
 assert len(sources)==42 and all(s['source_url'] in links and s['source_url'] in md for s in sources)
 assert all(s[k] for s in sources for k in ['source_url','publisher','observation_period','geography','units','extraction_date'])
 assert all(s['geography']!='research' for s in sources)
 obs=list(csv.DictReader((out/'support/report-observations.csv').open(encoding='utf-8-sig')));assert len(obs)==102
 # Verify all CSV exports, closing the summary-only --check limitation.
 expected=model.build(model.load());csv_fields=0
 for name,ers in expected.items():
  with (ROOT/'models/integrated-outputs'/(name+'.csv')).open() as f:actual=list(csv.DictReader(f))
  assert len(actual)==len(ers),name
  for er,ar in zip(ers,actual):
   for k,v in er.items():
    if isinstance(v,(int,float)) and not isinstance(v,bool):
     assert math.isclose(float(ar[k]),v,rel_tol=1e-12,abs_tol=1e-6),(name,k,v,ar[k])
    else:assert ar[k]==('' if v is None else str(v)),(name,k,v,ar[k])
    csv_fields+=1
 # Preserve old master research and models; governance and current narrative may evolve.
 baseline=json.loads((ROOT/'research/p5a-baseline-hashes.json').read_text());preserved=[]
 for path,digest in baseline.items():
  assert sha(ROOT/path)==digest,'Legacy baseline changed: '+path;preserved.append(path)
 # All pages rendered; final correction only changed one already re-inspected page.
 compare=json.loads((ROOT/'research/production/final-pixel-comparison.json').read_text())
 assert compare['identical_pages']==[i for i in range(1,28) if i!=1] and compare['changed_pages']==[1]
 checks={'status':'PASS','final_build':'build-07','pdf_pages':len(pdf.pages),'a4_portrait_pages':27,'numbered_exhibits':len(captions),'editable_tables':len(doc.tables),'data_generated_charts':len(doc.inline_shapes),'source_refs':42,'observation_trace_rows':102,'docx_table_cells_matched_in_pdf_and_md':len(cells),'csv_export_fields_compared':csv_fields,'preserved_baseline_files':len(preserved),'pdf_source_links':sum(len(p.get('/Annots',[])) for p in pdf.pages),'pdf_bookmarks':len(pdf.outline),'visual_gate':'author full-page visual inspection; build05all27; build06page6 re-viewed; build07titlepage re-viewed,26pixel-identical','artifact_sha256':{p.name:sha(p) for p in [out/'investment_report.pdf',out/'investment_report.docx',out/'investment_report.md']}}
 (ROOT/'research/production/final-report-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print(json.dumps(checks,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
