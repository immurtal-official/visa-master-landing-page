import copy,json,pathlib,unittest
import integrated_market_model as M

class IntegratedModelTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.a=M.load();cls.o=M.build(cls.a)
 def close(self,x,y):self.assertAlmostEqual(x,y,delta=max(1e-7,abs(y)*1e-10))
 def test_global_is_gc_plus_residual_not_sum_with_gc(self):
  for sc,s in self.a['scenarios'].items():
   ev,b=M.events(self.a,s);self.close(sum(ev.values()),b['global_origin_trip_equivalents']);self.close(sum(ev[g] for g in ['CN','HK','MO','TW']),b['gc_origin_trip_equivalents']);self.assertGreater(ev['ROW'],0)
 def test_typed_fx_and_local_quote(self):
  for r in self.o['geographic_market']:
   if r['geography'] in self.a['geographies']:
    self.close(r['trip_quote_usd'],r['trip_quote_local']*self.a['fx'][r['currency']]['usd_per_local'])
  self.close(self.a['fx']['CNY']['usd_per_local']*6.6702,1)
 def test_trip_units_not_double_frequency(self):
  for r in self.o['geographic_market']:
   if r['geography'] in self.a['geographies']:
    s=self.a['scenarios'][r['scenario']];g=self.a['geographies'][r['geography']]
    self.close(r['annual_equivalent_accounts']*s['trip_frequency']*g['trip_frequency_multiplier'],r['eligible_payer_party_trips'])
    self.assertLessEqual(r['annual_equivalent_accounts'],g['population_guardrail'])
 def test_subscription_and_trip_payments_exclusive(self):
  s=copy.deepcopy(self.a['scenarios']['base']);s['subscriber_share']=1;r=M.revenue(self.a,s,'CN',1000)
  self.assertEqual(r['per_trip_paid_baskets'],0);self.close(r['subscription_accounts'],1000)
  s['subscriber_share']=0;s['per_trip_payment']=1;r=M.revenue(self.a,s,'CN',1000);self.close(r['per_trip_paid_baskets'],3000);self.assertEqual(r['subscription_revenue_usd'],0)
 def test_zero_core_payment_not_hidden_conversion(self):
  s=copy.deepcopy(self.a['scenarios']['base']);s['subscriber_share']=s['per_trip_payment']=0;r=M.revenue(self.a,s,'CN',1000)
  self.assertEqual(r['core_digital_revenue_usd'],0);self.assertEqual(r['core_paying_account_equivalents'],0);self.assertGreater(r['booking_net_revenue_usd'],0)
 def test_extension_off_excludes_all_government_and_gmv(self):
  r=M.revenue(self.a,self.a['scenarios']['base'],'CN',1000,extension_scale=0)
  self.close(r['integrated_revenue_usd'],r['core_digital_revenue_usd']);self.assertEqual(r['booking_gmv_usd'],0);self.assertEqual(r['visa_net_revenue_usd'],0)
 def test_market_and_forecast_reconciliation(self):
  for r in self.o['geographic_market']:
   self.close(r['integrated_tam_usd'],r['core_tam_usd']+r['booking_extension_tam_usd']+r['visa_extension_tam_usd']);self.assertLessEqual(r['core_near_sam_usd'],r['core_expanded_sam_usd']);self.assertLessEqual(r['integrated_expanded_sam_usd'],r['integrated_tam_usd'])
  for r in self.o['forecast']:
   self.close(r['integrated_revenue_usd'],r['core_digital_revenue_usd']+r['booking_net_revenue_usd']+r['visa_net_revenue_usd'])
   self.close(r['gross_profit_usd'],r['integrated_revenue_usd']-r['total_cogs_usd']);self.close(r['contribution_profit_usd'],r['gross_profit_usd']-r['payment_channel_cost_usd']-r['acquisition_budget_usd']);self.close(r['operating_profit_usd'],r['contribution_profit_usd']-r['fixed_people_content_admin_usd']);self.close(r['operating_cash_proxy_usd'],r['operating_profit_usd']-r['development_capex_usd'])
   self.close(r['active_accounts'],r['new_activated_accounts']+r['retained_active_accounts']);self.close(r['new_activated_accounts'],r['realized_paid_new_accounts']+r['realized_organic_new_accounts']);self.assertLessEqual(r['active_accounts'],min(r['active_sam_cap'],r['active_delivery_cap'])+1e-6)
 def test_costs_charge_free_users(self):
  a=copy.deepcopy(self.a)
  for s in a['scenarios'].values():s['subscriber_share']=s['per_trip_payment']=s['booking_attach']=s['visa_buy_fraction']=0
  mr,_=M.markets(a,'base');fr,_=M.forecast(a,'base',mr)
  for r in fr:self.assertEqual(r['integrated_revenue_usd'],0);self.assertGreater(r['full_stack_usage_cogs_usd'],0);self.assertLess(r['operating_profit_usd'],0)
 def test_aggregate_forecasts_sum_four_origins(self):
  for sc in self.a['scenarios']:
   for y in range(1,6):
    rs=[r for r in self.o['forecast'] if r['scenario']==sc and r['year']==y];gc=next(r for r in rs if r['geography']=='Greater_China');gl=next(r for r in rs if r['geography']=='Global');row=next(r for r in rs if r['geography']=='ROW')
    for k in ['integrated_revenue_usd','active_accounts','operating_profit_usd','booking_gmv_usd']:
     self.close(gc[k],sum(r[k] for r in rs if r['geography'] in ['CN','HK','MO','TW']));self.close(gl[k],gc[k]+row[k])
 def test_module_allocation_not_sum_standalone_tams(self):
  for h in self.o['headline']:
   rows=[r for r in self.o['module_bridge'] if r['scenario']==h['scenario'] and r['geography']==h['geography']]
   self.close(sum(r['allocated_core_tam_usd']+r['incremental_extension_tam_usd'] for r in rows),h['integrated_tam_usd'])
 def test_channel_budget_and_unique_activation(self):
  for f in self.o['forecast']:
   if f['geography'] not in self.a['geographies']:continue
   ch=[r for r in self.o['channels'] if r['scenario']==f['scenario'] and r['geography']==f['geography'] and r['year']==f['year']]
   self.close(sum(r['budget_usd'] for r in ch),f['acquisition_budget_usd']);self.close(sum(r['dedup_activated_new'] for r in ch),f['paid_new_activated_accounts_before_capacity'])
   if f['realized_paid_new_accounts'] and f['core_paying_account_equivalents']:
    prob=f['net_retained_core_payer_equivalents']/f['active_accounts'];self.close(f['core_cac_per_new_payer_usd'],f['acquisition_budget_usd']/(f['realized_paid_new_accounts']*prob))
 def test_target_backsolve(self):
  for r in self.o['target_100m']:self.close(r['required_active_accounts_integrated']*r['integrated_revenue_per_active_usd'],1e8)
 def test_scenario_order_and_sensitivity(self):
  for geo in ['Global','Greater_China']:
   hs={r['scenario']:r for r in self.o['headline'] if r['geography']==geo}
   for k in ['core_tam_usd','integrated_tam_usd','integrated_y5_som_usd']:self.assertLess(hs['conservative'][k],hs['base'][k]);self.assertLess(hs['base'][k],hs['optimistic'][k])
   sr=[r for r in self.o['sensitivity'] if r['geography']==geo and r['grid']=='pay_x_price' and r['pay_factor']==1];sr.sort(key=lambda r:r['price_factor']);self.assertLess(sr[0]['y5_revenue_usd'],sr[1]['y5_revenue_usd']);self.assertLess(sr[1]['y5_revenue_usd'],sr[2]['y5_revenue_usd'])
 def test_input_has_provenance_and_no_false_actual_claim(self):
  for r in self.a['source_anchors'].values():
   for k in ['source_url','publisher','publication_date','observation_year','geography','unit','extraction_date','limitations']:self.assertIn(k,r)
  self.assertEqual(self.a['confidence'],'low');self.assertIn('unverified',self.a['actual_pipeline_contracts'])
 def test_output_reproducible(self):self.assertEqual(self.o,M.build(self.a))

if __name__=='__main__':unittest.main()
