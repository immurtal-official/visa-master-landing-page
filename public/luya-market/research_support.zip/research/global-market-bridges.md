# P5-A：以可审计假设补足全球及港澳旅行分母

本工作流的交付为补充来源表、参数 JSON 和本说明。基础研究截止日为 **2026-10-29**；下列补充核验均在 **2026-10-30** 完成，不能倒签为前一日可得证据。产品规划只决定待评估服务范围。分母、消费额与付费转化分别建模。

## 全球国内旅行可完成情景估算，不能冒充已观测总量

WTTC 当前官方页面列出 2025 年国内游客消费 **USD 5.63tn**、国际游客消费 **USD 2.02tn**。这是 WTTC／Oxford Economics 的行业模型估计；网页没有明确更新日期，仍残留将 2025 年称为预测年的旧说明。链接的 World Factsheet 产品页标注 2026-05-12 发布，且说明历史数据每年修订；此次未取得与当前网页数字完全对应的定版 PDF。因此采用“2026 EIR 页面所载 2025 年估计”，避免写成政府终值或将产品发布日期当作网页更新时间。[WTTC EIR](https://wttc.org/Research/Economic-Impact)、[World Factsheet 产品页](https://researchhub.wttc.org/product/factsheet-world-travel-tourism-economic-impact-research)。

此次恢复了 [UN Tourism 国内旅次原始 XLSX](https://pre-webunwto.s3.amazonaws.com/s3fs-public/2025-12/UN_Tourism_domestic_trips_12_2025.xlsx)，已保存至 `evidence/raw/p5a-market-un-domestic-dec2025.xlsx`。工作簿 Overview 页声明 2025-12-23 更新；Data 表包含 1995–2024 年，2024 年有 46 个报告地区、没有 World 行，也没有 2025 年观测。总访问、过夜、即日三项彼此重叠，不能逐项相加。它解决了下载缺口，但不能产生同口径的 2025 全球分母。[官方入口](https://www.untourism.int/tourism-statistics/tourism-data-domestic-tourism)。

建议使用以下 **analyst assumption**，将结果命名为“国内 person-trip equivalents”，而非 UN 官方旅次：

| 参数／结果 | 保守 | 基准 | 乐观 |
| --- | ---: | ---: | ---: |
| 假设每人每旅次消费，USD | 500 | 350 | 250 |
| 5.63tn ÷ 单次消费，十亿旅次当量 | 11.260 | 16.086 | 22.520 |

区间通过以下异质区域锚点校准，没有声称是抽样加权的全球均值：

| 2025 年区域锚点 | 来源事实 | 推导值 | 主要边界 |
| --- | --- | ---: | --- |
| 美国 | 国内 2.40bn person-trips；支出 USD 1.185tn | USD 493.75／旅次 | 来源列于 ACTUAL 栏，仍为行业模型；支出为 real 2025 USD |
| EU27 | 国内 848m 过夜旅次；EUR 266.2bn | EUR 313.915／旅次 | 15 岁以上居民；不含即日游；私人及公务合计 |
| 中国大陆 | 国内 6.522bn 人次；CNY 6.30tn | CNY 965.961／人次 | 样本推算旅行事件，非独立旅行者 |
| 台湾 | 国内 247.614m 旅次；TWD 564.3bn | 来源直接报告 USD 73.12／旅次 | 12 岁以上国民，含即日游；源表年度汇率 TWD 31.166／USD |

来源：[U.S. Travel Spring 2026，PDF 第 1–2 页](https://www.ustravel.org/sites/default/files/2026-05/US_Travel-Forecast_Spring26.pdf)，其[发布页](https://www.ustravel.org/research/travel-forecasts)标题日期 2026-05-07；[Eurostat，2026-10-09](https://ec.europa.eu/eurostat/web/products-eurostat-news/w/ddn-20261009-1)；[文旅部，2026-06-02](https://zwgk.mct.gov.cn/zfxxgkml/tjxx/202606/t20260602_966073.html)；[台湾旅状调查，PDF 表 1](https://www.taiwan.net.tw/dn.aspx?uid=30464)，[附件发布页，2026-08-03](https://www.taiwan.net.tw/m1.aspx?sNo=0044519)。

美国国内休闲旅次 1.95bn／国内总旅次 2.40bn，推导约 81.25%；这只是区域参照，不是全球休闲率。上表不进行跨币种支出加总，也不把年龄、过夜和即日定义不同的旅行数机械当成统一全球下限。500／350／250 USD 是需敏感性测试的估计参数；全球价格基准和口径误差应降低分母置信度。

## 国际到访与客源旅程需要显式桥接

既有 2026-10-29 来源链使用 UN 2025 年 provisional 国际过夜到访 1.544bn。它按目的地计数，同一人的多国行程可产生多个 arrival，不能直接等于独立出发旅程，更不是独立用户。

可设“每次客源行程访问的外国目的地数”为 1.20／1.10／1.05，分别用于保守／基准／乐观，计算 `客源跨境旅程当量 = 国际到访 ÷ 目的地数`。这些数是 **analyst assumptions**，本次没有取得全球行程国家数的观测分布。继续对休闲、FIT、数字可达及付费需求作条件过滤时，应分别说明分母；不能把多个边际调查比例当作已验证联合概率。

全球口径包含大中华区；大中华区只能作为子集展示。中国大陆居民赴港澳台已经属于大陆出境客源池，目的地入境统计不能再加一次。港澳台居民进入大陆则属于各自居民客源，不能只因目的地在大陆便全部扣除；需要控制的是非通常居民、转口重复事件和行程链重复。

## 港澳边境离境事件应保留非零情景，目的比例仍属假设

既有 2026-10-29 核验的香港居民离境 117.542m、澳门居民离境 42.900684m，包含通勤、商务、探亲、购物等事件，不能全部当作休闲旅行。来源：[香港统计处《Hong Kong in Figures 2026》表 13.11](https://www.censtatd.gov.hk/en/data/stat_report/product/B1010006/att/B10100062026AN26B0100.pdf)、[澳门旅游局 Global Indicators，2026 年 2 月期](https://dataplus.macaotourism.gov.mo/document/CHT/Report/GlobalIndicators/2026/Global%20Indicators%20%202026%20Feb.pdf)。此两项沿用原核验日期，本次没有重新打开原表。

补充核验的 VisitBritain 官方市场页载香港客源 2025 年境外访问 **34.2m**，包括中国内地及澳门。其方法章节列 Oxford Economics、UNWTO、ONS 等混合来源，未逐项交代该指标的测量方法；所以它是官方旅游机构采用的外部估计，不能当成香港政府观测的休闲比例。34.2／117.542≈29.1% 只用于检查分析假设的数量级。[VisitBritain 香港客源页](https://www.visitbritain.org/research-insights/inbound-markets/hong-kong-sar)。

| 假设：每次居民离境对应的旅游旅程当量 | 保守 | 基准 | 乐观 | 证据级别 |
| --- | ---: | ---: | ---: | --- |
| 香港 | 20% | 30% | 40% | C；外部估计校准，非直接观测 |
| 澳门 | 15% | 25% | 40% | D；未恢复全年居民目的调查，纯分析假设 |

这里先过滤“旅游而非例行跨境”，若模型随后再过滤休闲，应确保第一层没有已经定义成休闲，以免重复折扣。澳门不能用旅行社组织量或旅行社非随团量代替全部自行出境居民。

港澳本地 staycation、城市探索和日常拍照也不能被写成“需求为零”。若纳入完整全球／大中华 TAM，可用经独立核验的通常居民人口乘以每人每年 0.25／0.50／1.00 次可服务本地休闲旅行，再通过相同付费过滤；频次完全属于 D 级假设。若首期 SAM 明确定义为跨境服务，则将其排除并列为未计价的扩展池。两种处理均需明示，不应把无观测值默认为事实零。

## 交接与停止标准

`evidence/p5a-market-bridges.json` 保存 15 条本次核验来源事实、3 条明确标示的基础研究复用事实、推导公式、假设及下载审计；`evidence/p5a-market-sources.csv` 保存逐来源 URL、出版／提取日期、单位和限制。新工作仅补充当前核验，不修改旧报告或主来源表。模型执行文件应消费这些输入并覆盖单位、情景顺序及全球／区域核对。

已取得全球消费锚点、三类区域旅次消费参照、UN 原表覆盖验证和港澳非零假设框架，足以完成可审计情景模型。本工作流停止继续搜寻；未获观测的数据保留为显式假设，由验证计划取代虚构的研究闭环。
