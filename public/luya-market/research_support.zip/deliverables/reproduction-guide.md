# Luya 投资研究交付与复跑说明

版本：2026-10-30。主报告27页A4，33个编号展项，42条报告来源；PDF为主要阅读版本。DOCX为真实样式／可编辑表格，Markdown与两者同源。报告中的TAM、SAM、SOM与财务为低置信度分析师情景，非公司实绩或统计置信区间。

## 文件与模型入口

- `investment_report.pdf`、`investment_report.docx`、`investment_report.md`：最终报告。
- `support/headline.csv`：Global、大中华四地／合计、ROW三情景TAM、两种SAM、Y3／Y5SOM；均为年度平台收入USD。
- `support/forecast.csv`：2027E–2031E五年三情景账户、旅次、订阅、按次、GMV／净佣金、费用、利润与现金。
- `support/module_bridge.csv`、`geographic_market.csv`、`event_bridge.csv`：收入和地域去重、付款计量桥。
- `support/channels.csv`、`sensitivity.csv`、`target_100m.csv`：预算分发、二维敏感性、USD100M反解。
- `support/integrated-scenario-assumptions.json/.csv`：可编辑报价、采用／支付、频次、预算、容量和成本；全部商业假设均标未验证。
- `support/report-sources.csv`与`report-observations.csv`：42条引用与102条逐值追溯；新市场补证另见p5a文件。URL、机构、日期、观察期、地域、单位及局限保留。
- `support/*review.md`：独立AI定向模型／内容审阅，非外部会计鉴证。完整档案及旧批次留在项目`evidence/raw`、`audits`，未把机构原版报告重新打包分发。

## 复算财务

`research_support.zip`保留必要目录结构，解压后在包根运行；金融模型只需Python标准库。

```sh
python3 models/integrated_market_model.py --check
python3 -m unittest discover -s models -p 'test_integrated_market.py'
```

修改`evidence/integrated-scenario-assumptions.json`后，运行：

```sh
python3 models/integrated_market_model.py
```

`--check`严格对比summary JSON；已公布CSV还由`models/report/validate_report.py`逐字段复算检查（相对容差1e-12、绝对容差USD1e-6，用于不同Python小版本浮点顺序）。修改假设会使旧审阅和出版文件失效，应重跑针对性审阅及报告，不可只手改PDF。Global包含大中华，不能相加；GMV、政府费、供应商本金和Credits面值不属于平台收入。

## 重建出版文件

内容与图表生成器为`models/report/build_report.py`，排版助手为`docx_layout.py`。使用Codex工作区依赖中的Python（python-docx、Pillow）及文档技能`render_docx.py`，以DOCX导出PDF；实际字体Songti SC、Hiragino Sans GB、Arial。`research/production/fonts.conf`提供中文字体查找，换路径／系统时须调整并再次验证缺字。模型计算不依赖这些排版字体。

```sh
<bundled-python> models/report/build_report.py
FONTCONFIG_FILE=<project>/research/production/fonts.conf <bundled-python> <documents-skill>/render_docx.py deliverables/investment_report.docx --output_dir research/production/new-build --emit_pdf
```

Markdown图片位于`support/figures`；移动Markdown时一并保留该相对目录。支持压缩包只含复算所需模型／证据与选择的制作记录；完整旧模型、全页PNG、历史保全检查应在原项目执行。Word在其他字体环境可能重新分页；主要呈现以已验收PDF为准。

## 已完成的校验

全项目152项模型测试通过；独立模型重算5,376字段一致。最终926个表格单元在PDF、DOCX、MD逐项匹配，10,995个CSV输出字段重算匹配。全部27页已实际打开目检；最终小修后26页像素相同、修订第6页重新目检。所有PDF字体嵌入、42个原文链接、30个导航书签、A4页幅与页码已核查。逐页记录在`research/report-qa-log.csv`；未闭合商业数据见`research/remaining-unknowns-current.md`。

无广告投放、真实收费、访谈、外联或运营实验发生。90天方案是下一项经营验证提案，未用模拟数据冒充结果。
