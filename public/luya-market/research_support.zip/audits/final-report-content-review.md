# 最终报告内容一致性独立复核

复核日：2026-10-30。范围为 `deliverables/investment_report.md`、`deliverables/support/report-sources.csv` 与当前整合模型输出、observations、competition-current及原source登记的有界比对。不开展新外部取证，不重复全来源审计，不检查版式；未修改报告、模型或证据文件。审阅者未参与本次整合模型构建。这是内部AI内容复核，不是外部鉴证。

## 结论

**未发现会改变核心结论的major/critical数值或财务标签错误；有2项minor整改。** 表中TAM/SAM/SOM及财务数字可以与保存输出核对，已充分标为低置信度分析师情景；新增数字不等于已验证需求。两项整改均已实时通知主负责人。

本结论仅绑定下列哈希版本。整改及后续排版再生后，需对这两项定点复验；不应把本审阅说成对未来版本的无条件认证。

## FRC-01 / minor：ROW近端覆盖率被舍入成2%，与模型2.5%不一致

位置：报告第205行，Exhibit10“其他地区”近端覆盖。

实际报告写2%，而 `evidence/integrated-scenario-assumptions.json`、`research/integrated-model-methodology.md` 及实际模型为2.5%。ROW基准核心TAM832.646m×2.5%=20.816m，整合TAM1,430.334m×2.5%=35.758m；与Global近端SAM155.938m回加一致。使用2%会误导读者复算。

精确整改：该格改为 **2.5%**，扩展18%不变；将生成器百分比格式改为必要时保留一位小数，避免重建报告时再舍入成2%。不调整模型或其他市场金额。

状态：open，已通知主负责人。

## FRC-02 / minor：最终来源CSV的结构化观察字段在37/42行为空

文件：`deliverables/support/report-sources.csv`。37条来自原登记的source行缺失observation_period/geography/units/extraction_date四个字段；S01/S02/S06–08/S11–42均存在这一模式。accessed_date及report_scope/limitations通常保留日期或口径，因此不是虚构引用，也不表示底层观测没有溯源；但当前导出不足以作为报告承诺的独立结构化数值索引。

精确整改：以本报告实际引用的observation/claim建立 **report_ref→observation_id/claim_id→值、scale、单位、币种、地域、观察期、提取日** 桥；或从这些选用行聚合填入来源CSV的相应字段。一个来源有多个期间/单位时保留集合或逐观察拆行，不要一律补2025（2030预测、2026点时价格不同）。API更新日、PDF修订日与首次发布日继续分开；仅有accessed_date时不要冒充新一次extract。对没有数值的功能声明明确not_applicable或claim级期间，不默填0。支持包应包含可定位的桥与原观察记录。

状态：open，已通知主负责人。它是导出完整性问题，未导致报告现有关键数值错误。

## 已核对且通过的关键内容

- Exhibit1六组Global/GC×三情景的TAM、近端/扩展SAM、2029E/2031E SOM，逐项与headline.csv按百万美元一位小数核对一致。Global已含GC，报告没有把两者相加。
- Exhibit6/7/9及模块桥的基准TAM结构与地域金额一致；纯数字、预订和签证扩展分开。SAM是分析师覆盖假设，不是当前已开通合同或城市事实。
- Exhibit17/18两张五年基准表的整合收入、COGS、毛利、支付渠道、获客预算、获客后贡献、人员内容、经营预算和简化现金流，逐项与forecast.csv核对至百万美元两位小数一致。
- Exhibit20基准2031E Global经营亏损1.407m、GC亏损1.276m，以及累计最低资金缺口11.257m/7.774m，与输出一致；融资额、税/营运资金、正式会计利润的限制明确。
- Exhibit21的11.01/8.42 USD CAC确实用退款后净付款账户分母，与模型相符；付费账户当量在五年表则明确是退款前收费当量。数字收入/收费账户9.44/7.54对应退款前收费分母，未被误标为净留存付费用户ARPPU。
- LTV5.13/4.07按全体活跃账户且含平台固定COGS近似计算；报告明确与payer CAC分母不同、不能直接计算LTV/CAC，未称成熟cohort实绩。毛利率66.7%/62.4%、获客后贡献率27.4%/23.3%及免费用量1.67m/1.20m等均与输出一致。
- Exhibit24同收入组合反解100m目标的活跃账户19.25m/22.59m、纯数字35.38m/43.58m、旅组旅次61.11m/73.40m、GMV1,601.2m/1,696.0m与target_100m.csv一致；文中没有把代数反解写成可实现的获客或到达时间预测。
- AI2025的6.02亿及42.8%对应OBS-P4A-C25-N/P；2026上半年“突破7亿”为OBS-P4A-C26-N严格下界。报告未算精确增速、未把全国AI人数改成旅行AI或付费人数。此次是原记录比对，不是重新验证CNNIC调查方法。
- Booking26.9bn/186.1bn、Expedia14.733bn/119.590bn、Airbnb12.241bn/91.3bn与533m混合夜晚/席位、Trip.com62.4bn CNY、同程19.396bn CNY及45.5m月付费交易用户，与现有公司观察/竞争记录相符；集团比率未被写成Luya affiliate费率。
- 签证表的申根12,201,026申请/10,265,942签发、CHINA1,915,149及HK/MO/TW15,954/343/1,728、日本7,862,060、UK约2.2m及中国籍472,510与现有观察一致。申请地/国籍/居住地、全部签证/旅游专属、申请/签发等限制已保留，未拼成共同客户分母。
- Layla停新订及续费文本矛盾、Wanderlog未锁ISO币种、Meitu与TripIt不同权益、Qwen为公开测试、Ask Maps初期美国/印度等限定，与competition-current一致。
- 币种/期间脚注明确2025数量锚点、2026建议价格与冻结FX，2027E–2031E假设经营期；没有把情景TAM写成官方2025 AI实际收入。WTTC价格基年未完全核实、异质旅次代理及ROW残差仍是模型限制，报告不因此获得统计精度。
- 调研、收费、广告、访谈、留存实验均标为尚未执行；90天门槛标为分析师设计。多模块数字收入是同一付款池的35/30/25/10%分摊，不是独立WTP证明。

## 实际比对版本

| 文件 | SHA256 |
|---|---|
| deliverables/investment_report.md | ede2b1fec4e13e2b5c88c0ffbbee7aac4636f319bd05de3a0ff3167891cb42c9 |
| deliverables/support/report-sources.csv | 7015c4a67471db3815a3493bd6b379a12dbf417840e6b4112432479fa35af2e5 |
| models/integrated-outputs/headline.csv | 81ceeea30ba73fa00617a7d04d68d19b2e791c0bcbebe0d0fbef6c4a836bec8b |
| models/integrated-outputs/forecast.csv | 61758e4616a86ee8bbc393c32a4564e34f1c93a1a1cd4966b9977225eb72e5b1 |
| models/integrated-outputs/target_100m.csv | b997db08eaaed2ccbb9ddab2cd43a56ae93ec1baa370903772be8b51efd849ab |
| evidence/observations.csv | fbeac59d70ef5f83558c5d019a8521a23f6dcd9abb71748744845cc24e5019bf |
| evidence/competition-current.csv | 905b254068f706ba2347bd866b9db4d9d49218574b08abaae10ca2688e581027 |
| evidence/sources.csv | 941c6784ae6663c5feed7b8c55ba10e5bddfb6f26dd08c57a2db6d4958cc964c |
| evidence/integrated-scenario-assumptions.json | c424d038c45f690d364828093909efa1676b3f754f8fc0dfb212658df32a5122 |

本次接受标准为完成上述有界内容一致性复核并明确差异，不覆盖完整模型独立重建、每条原始来源实时刷新、工作负载测量或最终PDF/DOCX视觉QA。初始SRC-03/04商业实证限制不因数值情景或本次一致性复核而关闭。

## 整改复验补记：2026-10-30，最终内容版本

主负责人整改后，审阅者对当前文件重新执行独立定点核对。**FRC-01与FRC-02均PASS / remediation_verified**；上文open是初始版本状态，保留为审阅历史，以本补记为当前状态。

FRC-01：Exhibit10其他地区现为2.5%/18.0%，与模型相符；生成器保留一位小数。最终主标题为“Luya 全球与大中华区 市场及投资研究”，不影响已核对市场和经营数字。

FRC-02：42条来源的observation_period/geography/units/extraction_date均有值；无数值观察的产品声明采用source_level_see_scope等明确来源级标签，未把research当地域。新增report-observations.csv含102条无重复report_ref/observation_id组合；逐字段核对value、scale、unit、currency、geography、observation_year、extraction_date、source_id、definition、limitations，与原observations完全一致。每条与所列report_ref的精确source_id和URL相符。P5A来源使用其已有源级期间/单位等元数据，没有冒称主observations中不存在的新记录。无需新外部研究。

复验精确SHA256：

| 文件 | SHA256 |
|---|---|
| deliverables/investment_report.md | 6081be6f5403d6474ada7dacabc5e4ff04320e48164011d3d8542293e9ab36b5 |
| deliverables/support/report-sources.csv | f209f6646a4b978d9e2e9acf4baec2ace3b2f226d3f221e6525629e915f2c909 |
| deliverables/support/report-observations.csv | f46410f2fb6c40185ea35966754814cdfc2a4d7dda69a25312e04379cbf13417 |
| models/report/build_report.py | 97ead5ee1ddb31d413a80eb540a990c513c6a755ae324d8ca901bd2cc338a467 |

当前内容一致性复核无未关闭major/critical问题，两个minor已验证整改。该结论不关闭旧商业实证缺口，不涵盖PDF/DOCX最终视觉QA、运行日志成本或真实用户验证。

## 最终价格显示精度复验补记：2026-10-30

主负责人在最终视觉检查时发现Exhibit8的ROW建议单次价9.99被显示为10，并修正显示格式。审阅者独立核对当前MD行“其他地区／USD｜39｜9.99｜39”，与integrated-scenario-assumptions.json中ROW.trip_price=9.99完全一致，PASS。仅显示精度更新；假设JSON哈希保持不变，两份来源/观察台账哈希亦保持不变。未重开其他研究或检查范围。

以下为本次最终版本绑定，取代此前MD/生成器的版本哈希；前文初始审阅和整改历史保留。

| 文件 | 最终SHA256 |
|---|---|
| deliverables/investment_report.md | 1157b76d1a36fd2d44182982eb6f013dba3efdabf6970b3e9ebf996a98bb36de |
| deliverables/support/report-sources.csv | f209f6646a4b978d9e2e9acf4baec2ace3b2f226d3f221e6525629e915f2c909 |
| deliverables/support/report-observations.csv | f46410f2fb6c40185ea35966754814cdfc2a4d7dda69a25312e04379cbf13417 |
| models/report/build_report.py | cb023402bc61239a3ee924726f9653567c7b5bdfba3bd1bae1f22c9583b5512a |
| evidence/integrated-scenario-assumptions.json | c424d038c45f690d364828093909efa1676b3f754f8fc0dfb212658df32a5122 |

本次最终定点复验完成；既有商业实证限制及PDF/DOCX视觉QA范围界限不变。


