#!/usr/bin/env python3
"""Independent algebra reconstruction; never imports the integrated builder.

Reads only the three scoped input/output areas; emits JSON to stdout.
"""
import csv
import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parents[1]
A = json.loads((R/'evidence/integrated-scenario-assumptions.json').read_text())
O = R/'models/integrated-outputs'
SCOPES = {'Global': ['CN','HK','MO','TW','ROW'], 'Greater_China': ['CN','HK','MO','TW']}

def rows(name):
    with (O/(name+'.csv')).open() as f:
        return list(csv.DictReader(f))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

cells = 0
max_abs = 0
def check(value, saved, where):
    global cells,max_abs
    delta=abs(value-float(saved));max_abs=max(max_abs,delta);cells+=1
    assert delta <= max(1e-7,abs(value)*1e-11), (where,value,saved,delta)

def rev(sc,geo,active,roll=1):
    s=A['scenarios'][sc];g=A['geographies'][geo]
    trips=active*s['trip_frequency']*g['trip_frequency_multiplier']
    subscribed=active*s['subscriber_share']
    subscriber_trips=min(trips,subscribed*s['subscriber_trip_frequency']*g['trip_frequency_multiplier'])
    non_sub=active-subscribed
    non_sub_trips=trips-subscriber_trips
    pertrip_orders=non_sub_trips*s['per_trip_payment']
    payer=subscribed+non_sub*(1-(1-s['per_trip_payment'])**(non_sub_trips/non_sub)) if non_sub else subscribed
    rate=A['fx'][g['currency']]['usd_per_local']*s['price_factor']
    subgross=subscribed*g['annual_price']*rate
    tripgross=pertrip_orders*g['trip_price']*rate
    core=(subgross+tripgross)*(1-s['refund'])
    gmv=trips*s['booking_attach']*s['booking_settled_fraction']*g['booking_gmv_per_attached_trip_usd']*roll
    booking=gmv*s['booking_net_take']
    visa_tasks=trips*g['visa_need_per_trip']*s['visa_buy_fraction']*roll
    visa=visa_tasks*g['visa_price']*rate*(1-s['refund'])
    assert abs(subscriber_trips+non_sub_trips-trips)<1e-5
    assert subscribed<=active and pertrip_orders<=non_sub_trips
    assert g['annual_price'] < g['trip_price']*s['subscriber_trip_frequency']*g['trip_frequency_multiplier']
    return dict(active_accounts=active,served_party_trips=trips,subscription_accounts=subscribed,
        subscriber_party_trips=subscriber_trips,non_subscriber_party_trips=non_sub_trips,
        per_trip_paid_baskets=pertrip_orders,core_free_party_trips=non_sub_trips-pertrip_orders,
        core_entitled_party_trips=subscriber_trips+pertrip_orders,
        gross_charged_core_payer_equivalents=payer,net_retained_core_payer_equivalents=payer*(1-s['refund']),
        subscription_revenue_usd=subgross*(1-s['refund']),per_trip_revenue_usd=tripgross*(1-s['refund']),
        core_digital_revenue_usd=core,booking_gmv_usd=gmv,booking_net_revenue_usd=booking,
        visa_paid_tasks=visa_tasks,visa_net_revenue_usd=visa,integrated_revenue_usd=core+booking+visa,
        gross_core_billings_usd=subgross+tripgross)

saved_market={(r['scenario'],r['geography']):r for r in rows('geographic_market')}
saved_forecast={(r['scenario'],r['geography'],int(r['year'])):r for r in rows('forecast')}
saved_head={(r['scenario'],r['geography']):r for r in rows('headline')}
facts={k:v['value'] for k,v in A['source_anchors'].items()}
markets={};forecasts={};headlines=[];events=[]
for sc,s in A['scenarios'].items():
    domestic=facts['INT-WTTC-DOM2025']/s['global_domestic_spend_per_trip_usd']
    intl=facts['OBS-P3C-UN-ARRIVALS']/s['arrival_per_international_chain']
    global_events=domestic+intl-min(domestic,intl)*s['domestic_international_overlap']
    ev=dict(CN=facts['OBS-CN25-DOMTRIPS']+facts['OBS-CN25-OUT']*(1-s['domestic_international_overlap']),
        TW=s['tw_resident_adult_bridge']*(facts['OBS-TW25-DOM-PRECISE']+facts['OBS-TW25-OUT-ALLAGES']*(1-s['domestic_international_overlap'])),
        HK=facts['OBS-HK25-DEPART']*s['hk_leisure_departure_fraction']+A['geographies']['HK']['population_guardrail']*s['hk_mo_staycation_trips_per_person'],
        MO=facts['OBS-MO25-OUT-TOTAL']*s['mo_leisure_departure_fraction']+A['geographies']['MO']['population_guardrail']*s['hk_mo_staycation_trips_per_person'])
    ev['ROW']=global_events-sum(ev.values());assert ev['ROW']>0
    events.append(dict(scenario=sc,global_events=global_events,greater_china_events=global_events-ev['ROW'],row_residual=ev['ROW']))
    for geo,g in A['geographies'].items():
        eligible=ev[geo]*s[geo.lower()+'_joint_eligible']
        party=eligible/s['party_size'];account=party/(s['trip_frequency']*g['trip_frequency_multiplier'])
        active=account*s['category_adoption'];assert account<=g['population_guardrail']
        near=min(1,g['near_coverage']*s['near_coverage_scale']);expanded=min(1,g['expanded_coverage']*s['expanded_coverage_scale']);assert 0<=near<=expanded<=1
        v=rev(sc,geo,active)
        m=dict(origin_trip_equivalents=ev[geo],joint_eligible_person_trip_equivalents=eligible,eligible_payer_party_trips=party,
            annual_equivalent_accounts=account,category_active_accounts=active,near_active_accounts=active*near,expanded_active_accounts=active*expanded,
            core_tam_usd=v['core_digital_revenue_usd'],booking_extension_tam_usd=v['booking_net_revenue_usd'],visa_extension_tam_usd=v['visa_net_revenue_usd'],
            integrated_tam_usd=v['integrated_revenue_usd'],core_near_sam_usd=v['core_digital_revenue_usd']*near,
            integrated_near_sam_usd=v['integrated_revenue_usd']*near,core_expanded_sam_usd=v['core_digital_revenue_usd']*expanded,
            integrated_expanded_sam_usd=v['integrated_revenue_usd']*expanded)
        markets[(sc,geo)]=m
    for scope,geos in SCOPES.items():
        markets[(sc,scope)]={k:sum(markets[(sc,g)][k] for g in geos) for k in markets[(sc,'CN')]}
    for (scenario,geo),m in list(markets.items()):
        if scenario==sc:
            for k,v in m.items():check(v,saved_market[(sc,geo)][k],('market',sc,geo,k))
    prior={g:0 for g in A['geographies']};plan=A['company_plan']
    for y in range(1,6):
        i=y-1
        for geo,g in A['geographies'].items():
            m=markets[(sc,geo)]
            budget=plan['annual_acquisition_budget_usd'][i]*s['budget_factor']*g['channel_budget_share']
            raw=sum(budget*share/(g['cost_per_new_activated_usd']*s['acquisition_cost_factor']*multiple) for share,multiple in [(0.35,1.2),(0.45,1),(0.20,0.8)])
            paid=raw*.9;organic=plan['annual_unique_organic_new_accounts'][i]*s['organic_factor']*g['organic_share']
            cap_sam=(m['near_active_accounts']+(m['expanded_active_accounts']-m['near_active_accounts'])*plan['near_to_expanded_coverage_fraction'][i])*(1+s['trip_growth'])**y
            cap_delivery=plan['annual_active_account_capacity'][i]*s['capacity_factor']*g['capacity_share']
            cap=min(cap_sam,cap_delivery);retained=min(prior[geo]*s['retention'],cap);new=min(paid+organic,max(cap-retained,0));active=retained+new;prior[geo]=active
            assert active<=cap+1e-6
            v=rev(sc,geo,active,plan['booking_visa_rollout'][i])
            ai=v['served_party_trips']*s['cost_per_trip'];support=v['gross_charged_core_payer_equivalents']*s['cost_per_payer'];credit=active*s['credits_cost_per_active']
            bookingcost=v['booking_net_revenue_usd']*s['booking_servicing_fraction'];visacost=v['visa_net_revenue_usd']*s['visa_servicing_fraction']
            platform=plan['annual_platform_fixed_usd'][i]*s['staff_budget_factor']*g['capacity_share']
            grossprofit=v['integrated_revenue_usd']-ai-support-credit-bookingcost-visacost-platform
            channel=(v['gross_core_billings_usd']+v['visa_net_revenue_usd']/(1-s['refund']))*s['channel_fee']
            contrib=grossprofit-channel-budget
            fixed=plan['annual_fixed_people_content_admin_usd'][i]*s['staff_budget_factor']*g['capacity_share']
            capex=plan['annual_development_capex_usd'][i]*s['staff_budget_factor']*g['capacity_share']
            realized_paid=new*paid/(paid+organic) if paid+organic else 0
            v.update(new_activated_accounts=new,realized_paid_new_accounts=realized_paid,realized_organic_new_accounts=new-realized_paid,
                retained_active_accounts=retained,active_sam_cap=cap_sam,active_delivery_cap=cap_delivery,acquisition_budget_usd=budget,
                full_stack_usage_cogs_usd=ai,free_usage_cogs_usd=v['core_free_party_trips']*s['cost_per_trip'],
                paid_entitlement_usage_cogs_usd=v['core_entitled_party_trips']*s['cost_per_trip'],payer_support_cogs_usd=support,
                credits_redemption_cogs_usd=credit,booking_service_cogs_usd=bookingcost,visa_service_cogs_usd=visacost,fixed_platform_cogs_usd=platform,
                total_cogs_usd=ai+support+credit+bookingcost+visacost+platform,gross_profit_usd=grossprofit,payment_channel_cost_usd=channel,
                contribution_profit_usd=contrib,fixed_people_content_admin_usd=fixed,operating_profit_usd=contrib-fixed,development_capex_usd=capex,
                operating_cash_proxy_usd=contrib-fixed-capex)
            netnew=realized_paid*v['net_retained_core_payer_equivalents']/active
            v['core_cac_per_new_payer_usd']=budget/netnew if netnew else 0
            forecasts[(sc,geo,y)]=v
        for scope,geos in SCOPES.items():
            excluded=['core_cac_per_new_payer_usd']
            v={k:sum(forecasts[(sc,g,y)][k] for g in geos) for k in forecasts[(sc,'CN',y)] if k not in excluded}
            netnew=sum(forecasts[(sc,g,y)]['realized_paid_new_accounts']*forecasts[(sc,g,y)]['net_retained_core_payer_equivalents']/forecasts[(sc,g,y)]['active_accounts'] for g in geos)
            v['core_cac_per_new_payer_usd']=v['acquisition_budget_usd']/netnew if netnew else 0
            forecasts[(sc,scope,y)]=v
    for geo in list(A['geographies'])+list(SCOPES):
        cumulative=need=0
        for y in range(1,6):
            v=forecasts[(sc,geo,y)];cumulative+=v['operating_cash_proxy_usd'];need=max(need,-cumulative)
            v.update(cumulative_operating_cash_proxy_usd=cumulative,minimum_cumulative_funding_need_usd=need)
            for k,value in v.items():check(value,saved_forecast[(sc,geo,y)][k],('forecast',sc,geo,y,k))
    for scope in SCOPES:
        m=markets[(sc,scope)];h=dict(scenario=sc,geography=scope,**{k:v for k,v in m.items() if 'tam_usd' in k or 'sam_usd' in k})
        for y in [3,5]:h['integrated_y'+str(y)+'_som_usd']=forecasts[(sc,scope,y)]['integrated_revenue_usd'];h['core_y'+str(y)+'_som_usd']=forecasts[(sc,scope,y)]['core_digital_revenue_usd']
        h['y5_operating_profit_usd']=forecasts[(sc,scope,5)]['operating_profit_usd']
        for k,v in h.items():
            if isinstance(v,(int,float)):check(v,saved_head[(sc,scope)][k],('headline',sc,scope,k))
        headlines.append(h)

for row in rows('module_bridge'):
    m=markets[(row['scenario'],row['geography'])]
    expected=m['core_tam_usd']*A['modules'][row['module']] if row['module'] in A['modules'] else 0
    extension=m['booking_extension_tam_usd'] if row['module']=='Booking_Commissions' else m['visa_extension_tam_usd'] if row['module']=='Visa_Preparation' else 0
    check(expected,row['allocated_core_tam_usd'],('module',row['module']))
    check(extension,row['incremental_extension_tam_usd'],('extension',row['module']))
assert abs(sum(A['modules'].values())-1)<1e-12
for row in rows('target_100m'):
    f=forecasts[(row['scenario'],row['geography'],5)];unit=f['integrated_revenue_usd']/f['active_accounts']
    check(1e8/unit,row['required_active_accounts_integrated'],('target',row['scenario'],row['geography']))

aggforecast=[dict(scenario=sc,geography=geo,year=y,calendar_year=2026+y,**v) for (sc,geo,y),v in forecasts.items() if geo in SCOPES]
paths=[R/'models/integrated_market_model.py',R/'evidence/integrated-scenario-assumptions.json']+sorted(O.glob('*'))
print(json.dumps(dict(as_of=A['as_of'],method='Independent reconstruction from scoped assumption/source rows; no model module imports or tested builder functions',
    numeric_cells_reconciled=cells,max_absolute_float_difference=max_abs,tolerance='max(1e-7 USD/accounts,1e-11 relative); floating order only',
    all_reconciled=True,headlines=headlines,aggregate_forecast=aggforecast,event_bridge=events,
    file_sha256={str(p.relative_to(R)):sha(p) for p in paths if p.is_file()},
    confidence='low analyst scenarios; arithmetic agreement does not verify commercial or source assumptions'),ensure_ascii=False,indent=2))
